package com.example.mycityinfoapp;

//import android.support.v7.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

public class UserSearchActivity extends AppCompatActivity {
    private Button viewBtn;
    private ListView list_view;
    private EditText searchtxt;
    private String[] array, infonamearray, infolinkarray, emailidarray, phnumarray, infotypearray, addressarray;
    private FirebaseFirestore db;
    private String search;
    //private String arrayname, arraytype, arrayemail, arrayphnum, arrayaddress, arraylink;
    private ArrayList<String> arrayname, arraytype, arrayemail, arrayphnum, arrayaddress, arraylink;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_search);

        list_view = (ListView) findViewById(R.id.list_view);
        viewBtn = (Button) findViewById(R.id.show_button);
        searchtxt = (EditText) findViewById(R.id.editTextSearch);
        db = FirebaseFirestore.getInstance();

        arrayemail=arrayaddress=arraylink=arraytype=arrayphnum=arrayname=new ArrayList<>();
        viewBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                search = searchtxt.getText().toString().toLowerCase();
                if(TextUtils.isEmpty(search)){
                    searchtxt.setError("Search Text is Empty");
                    searchtxt.setFocusable(true);
                }else
                {
                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                    DatabaseReference myRef = database.getReference("NewInfo");
                    int cnt = 0;
                    myRef.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            String str = "";
                            for (DataSnapshot SubSnapshot : snapshot.getChildren()) {
                                NewInfoClass dbClass = SubSnapshot.getValue(NewInfoClass.class);
                                String ShowDataString = "";
                                ShowDataString = dbClass.getInfoName() + "," + dbClass.getInfoType() + "," + dbClass.getInfoLink() + "," +
                                        dbClass.getPhoneNum() + "," + dbClass.getEmailId() +
                                        "," + dbClass.getAddress();
                                //Log.d("Str : ", ShowDataString);

                                if(search.contains(dbClass.getInfoType().toLowerCase()) || search.contains(dbClass.getInfoName().toLowerCase())) {
                                    if (str.length() == 0)
                                        str = str + ShowDataString;
                                    else
                                        str = str + "\n" + ShowDataString;
                                }
                            }
                            System.out.println("Str : "+str);
                            array = str.split("\n");
                            infonamearray = new String[array.length];
                            infotypearray = new String[array.length];
                            emailidarray = new String[array.length];
                            phnumarray = new String[array.length];
                            infolinkarray = new String[array.length];
                            addressarray = new String[array.length];
                            for (int i = 0; i < array.length; i++) {
                                String s[] = array[i].split(",");
                                infonamearray[i] = s[0];
                                infotypearray[i] = s[1];
                                infolinkarray[i] = s[2];
                                phnumarray[i] = s[3];
                                emailidarray[i] = s[4];
                                addressarray[i] = s[5];
                            }
                            FillData();
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            System.out.println("Data Access Failed" + error.getMessage());
                        }
                    });
                }
            }
        });

        list_view.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(), UserSearchViewFullInfoActivity.class);
                intent.putExtra("name", infonamearray[i]);
                intent.putExtra("type", infotypearray[i]);
                intent.putExtra("email", emailidarray[i]);
                intent.putExtra("phnum", phnumarray[i]);
                intent.putExtra("link", infolinkarray[i]);
                intent.putExtra("address", addressarray[i]);
                startActivity(intent);
            }
        });

        list_view.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(), UserSearchViewFullInfoActivity.class);
                startActivity(intent);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
    public void FillData()
    {
        MyListAdapter adapter=new MyListAdapter(this, infonamearray, infotypearray, emailidarray,
                phnumarray, addressarray, infolinkarray);
        list_view = (ListView) findViewById(R.id.list_view);
        list_view.setAdapter(adapter);
    }
}