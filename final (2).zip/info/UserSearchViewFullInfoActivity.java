package com.example.mycityinfoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class UserSearchViewFullInfoActivity extends AppCompatActivity {

    private TextView txtname, txttype, txtemail, txtphnum, txtaddress;
    private Button btn;
    private ImageView image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_search_view_full_info);
        Intent intent = getIntent();
        String infoname = intent.getStringExtra("name");
        String infotype = intent.getStringExtra("type");
        String infoemail = intent.getStringExtra("email");
        String infophnum = intent.getStringExtra("phnum");
        String infolink = intent.getStringExtra("link");
        String infoaddress = intent.getStringExtra("address");

        txtname = (TextView) findViewById(R.id.txtinfoname);
        txttype = (TextView) findViewById(R.id.txtinfotype);
        txtemail = (TextView) findViewById(R.id.txtemailid);
        txtphnum = (TextView) findViewById(R.id.txtphonenum);
        txtaddress = (TextView) findViewById(R.id.txtaddress);
        btn = (Button) findViewById(R.id.button);
        image = (ImageView) findViewById(R.id.imageView2);

        txtname.setText("Info Name      : " + infoname);
        txttype.setText("Info Type      : " + infotype);
        txtemail.setText("Info Email     : " + infoemail);
        txtphnum.setText("Info Phone Num : " + infophnum);
        txtaddress.setText("Info Address   : " + infoaddress);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse(infolink); // missing 'http://' will cause crashed
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });

        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse(infolink); // missing 'http://' will cause crashed
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });
    }
}