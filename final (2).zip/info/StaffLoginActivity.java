package com.example.mycityinfoapp;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
//import android.support.v7.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.security.SecureRandom;
import java.util.List;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import android.os.Bundle;
import android.text.InputType;

import android.content.Context;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.constraintlayout.widget.ConstraintLayout;

import java.nio.charset.StandardCharsets;
import java.security.*;

public class StaffLoginActivity extends AppCompatActivity {
    private Button loginBtn, gobackBtn, forgotpwdbtn;
    private FirebaseFirestore db;
    private String uname, pwd;
    private Boolean flag;
    private EditText txtUname, txtPwd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_login);
        loginBtn = (Button) findViewById(R.id.buttonlogin);
        //forgotpwdbtn= (Button) findViewById(R.id.buttonforgotpwd);
        gobackBtn= (Button) findViewById(R.id.gobackBtn);

        txtUname = (EditText)findViewById(R.id.editTextUname);
        txtPwd = (EditText)findViewById(R.id.editTextPassword);
        db = FirebaseFirestore.getInstance();


        txtUname.setText("staff");
        txtPwd.setText("1234");

        gobackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag = false;
                uname = txtUname.getText().toString();
                pwd = txtPwd.getText().toString();
            }
        });
    }
}