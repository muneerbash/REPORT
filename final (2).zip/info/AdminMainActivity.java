package com.example.mycityinfoapp;

//import android.support.v7.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class AdminMainActivity extends AppCompatActivity {
    private Button newstaffbtn, newinfobtn, viewinfobtn, viewstaffsbtn, viewusersbtn, gobackbtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_main);

        newinfobtn=(Button)findViewById(R.id.newinfobtn);
        newstaffbtn = (Button) findViewById(R.id.newstaffbtn);
        viewstaffsbtn = (Button) findViewById(R.id.viewstaffsbtn);
        viewinfobtn = (Button) findViewById(R.id.viewinfobtn);
        viewusersbtn = (Button) findViewById(R.id.viewuserbtn);
        gobackbtn = (Button) findViewById(R.id.gobackbtn);

        newstaffbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), NewStaffActivity.class);
                startActivity(intent);
            }
        });

        newinfobtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), NewInfoActivity.class);
                startActivity(intent);
            }
        });

        viewusersbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), AdminViewUsersActivity.class);
                startActivity(intent);
            }
        });

        viewstaffsbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), AdminViewStaffsActivity.class);
                startActivity(intent);
            }
        });

        viewinfobtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), AdminViewInfoActivity.class);
                startActivity(intent);
            }
        });

        gobackbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
    }
}