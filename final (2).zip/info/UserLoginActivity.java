package com.example.mycityinfoapp;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
//import android.support.v7.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.security.SecureRandom;
import java.util.List;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import android.os.Bundle;
import android.text.InputType;

import android.content.Context;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.nio.charset.StandardCharsets;
import java.security.*;

public class UserLoginActivity extends AppCompatActivity {
    private Button loginBtn, gobackBtn, forgotpwdbtn;
    private FirebaseFirestore db;
    private String uname, pwd, Id;
    private Boolean flag;
    private EditText txtUname, txtPwd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);
        loginBtn = (Button) findViewById(R.id.buttonlogin);
        //forgotpwdbtn= (Button) findViewById(R.id.buttonforgotpwd);
        gobackBtn= (Button) findViewById(R.id.gobackBtn);

        txtUname = (EditText)findViewById(R.id.editTextUname);
        txtPwd = (EditText)findViewById(R.id.editTextPassword);
        db = FirebaseFirestore.getInstance();

        txtUname.setText("aaa");
        txtPwd.setText("1234");

        gobackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uname = txtUname.getText().toString();
                pwd = txtPwd.getText().toString();

                if (TextUtils.isEmpty(uname)) {
                    txtUname.setError("User Name is Empty");
                    txtUname.setFocusable(true);
                } else if (TextUtils.isEmpty(pwd)) {
                    txtPwd.setError("Password is Empty");
                    txtPwd.setFocusable(true);
                } else {
                    // Adding addValueEventListener method on firebase object.
                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                    DatabaseReference myRef = database.getReference("Students");

                    myRef.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            flag=true;
                            for (DataSnapshot SubSnapshot : snapshot.getChildren()) {
                                NewUserClass newClass = SubSnapshot.getValue(NewUserClass.class);
                                if(newClass.getUserName().equals(uname)
                                        && newClass.getPassword().equals(pwd))
                                {
                                    Id = newClass.getUserId();
                                    flag=true;
                                    break;
                                }
                            }
                            if(flag)
                            {
                                Intent intent = new Intent(getApplicationContext(), UserMainPageActivity.class);
                                intent.putExtra("Id", Id);
                                startActivity(intent);
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            System.out.println("Data Access Failed" + error.getMessage());
                        }
                    });
                }
            }
        });
    }
}