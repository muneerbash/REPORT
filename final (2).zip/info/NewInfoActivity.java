package com.example.mycityinfoapp;

//import android.support.v7.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NewInfoActivity extends AppCompatActivity {

    private Button newinfobtn, gobackbtn;
    private Spinner infotypespinner;
    private EditText txtinfoName, txtAddress, txtEmailId, txtPhoneNum, txtInfoLink;
    private String Id, infoName, infoType, infoAddress, infoEmailId, infoPhoneNum, infoLink;
    private Spinner spinnerInfoType;
    private String[] infotypes;
    private ImageView imageCode;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_info);

        spinnerInfoType = (Spinner)findViewById(R.id.infotypespinner);
        infotypes=getResources().getStringArray(R.array.infotype);
        txtinfoName = (EditText) findViewById(R.id.editTextinfo);
        txtPhoneNum = (EditText) findViewById(R.id.editTextphnum);
        txtEmailId = (EditText) findViewById(R.id.editEmailid);
        txtAddress = (EditText) findViewById(R.id.editAddress);
        txtInfoLink = (EditText) findViewById(R.id.editinfolink);

        newinfobtn = (Button) findViewById(R.id.newinfobutton);
        gobackbtn = (Button) findViewById(R.id.gobackbutton);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_list_item_1, android.R.id.text1, infotypes);
        spinnerInfoType.setAdapter(adapter);

        gobackbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        newinfobtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                infoName=txtinfoName.getText().toString();
                infoEmailId=txtEmailId.getText().toString();
                infoPhoneNum=txtPhoneNum.getText().toString();
                infoType = spinnerInfoType.getSelectedItem().toString();
                infoAddress=txtAddress.getText().toString();
                infoLink=txtInfoLink.getText().toString();

                Pattern pattern = Pattern.compile("^\\d{10}$");
                Matcher matcher = pattern.matcher(infoPhoneNum);

                if(TextUtils.isEmpty(infoName))
                {
                    Toast.makeText(getApplicationContext(), "Information Name is Empty", Toast.LENGTH_SHORT).show();
                    txtinfoName.setFocusable(true);
                }
                else if(TextUtils.isEmpty(infoType))
                {
                    Toast.makeText(getApplicationContext(), "Information Type is Empty", Toast.LENGTH_SHORT).show();
                    spinnerInfoType.setFocusable(true);
                }
                else if(TextUtils.isEmpty(infoEmailId))
                {
                    Toast.makeText(getApplicationContext(), "Email Id is Empty", Toast.LENGTH_SHORT).show();
                    txtEmailId.setFocusable(true);
                }else if(!Patterns.EMAIL_ADDRESS.matcher(infoEmailId).matches())
                {
                    txtEmailId.setError("EmailId is Not Valid");
                    txtEmailId.setFocusable(true);
                }
                else if(TextUtils.isEmpty(infoPhoneNum))
                {
                    Toast.makeText(getApplicationContext(), "Phone Num is Empty", Toast.LENGTH_SHORT).show();
                    txtPhoneNum.setFocusable(true);
                }
                else if(!matcher.matches())
                {
                    txtPhoneNum.setError("Phone Num is Invalid should be 10 digits");
                    txtPhoneNum.setFocusable(true);
                }
                else if(TextUtils.isEmpty(infoAddress))
                {
                    Toast.makeText(getApplicationContext(), "Address is Empty", Toast.LENGTH_SHORT).show();
                    txtAddress.setFocusable(true);
                }
                else{
                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                    DatabaseReference dbRef = database.getReference();
                    dbRef = database.getReference("NewInfo");
                    Id = dbRef.push().getKey();
                    NewInfoClass newInfoClass =new NewInfoClass(Id, infoName, infoType,
                            infoEmailId, infoPhoneNum, infoAddress, infoLink);
                    dbRef.child(Id).setValue(newInfoClass);
                    Toast.makeText(getApplicationContext(), "New Info Inserted Successfully",
                            Toast.LENGTH_LONG).show();
                    /*
                    CollectionReference dbCourses = db.collection("NewStaff");
                    // adding our data to our courses object class.
                    NewStaffClass newStaffClass =new NewStaffClass(staffId, firstName, lastName, gender,
                            emailId, phoneNum, userName, password);
                    // below method is use to add data to Firebase Firestore.
                    dbCourses.add(newStaffClass).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {
                            // after the data addition is successful
                            // we are displaying a success toast message.
                            Toast.makeText(getApplicationContext(), "Staff has been added to Firebase Firestore", Toast.LENGTH_SHORT).show();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            // this method is called when the data addition process is failed.
                            // displaying a toast message when data addition is failed.
                            Toast.makeText(getApplicationContext(), "Fail to add staff \n" + e, Toast.LENGTH_SHORT).show();
                        }
                    });*/
                }
            }
        });
    }
}