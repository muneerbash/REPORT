package com.example.mycityinfoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class UserViewProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_view_profile);
    }
}