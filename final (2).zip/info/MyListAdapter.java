package com.example.mycityinfoapp;
import android.app.Activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class MyListAdapter extends ArrayAdapter<String>{
    private final Activity context;
    private final String[] infoname;
    private final String[] infotype;
    private final String[] emailid;
    private final String[] phnum;
    private final String[] address;
    private final String[] infolink;

    public MyListAdapter(Activity context, String[] infoname, String[] infotype,
                         String[] emailid, String[] phnum, String[] address, String[] infolink)  {
        super(context, R.layout.listadapter, infoname);
        // TODO Auto-generated constructor stub

        this.context=context;
        this.infoname=infoname;
        this.infotype=infotype;
        this.emailid=emailid;
        this.phnum=phnum;
        this.address=address;
        this.infolink=infolink;
        //this.imgid=imgid;
    }

    public View getView(int position,View view,ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.listadapter, null,true);

        TextView NameText = (TextView) rowView.findViewById(R.id.infoname);
        TextView TypeText = (TextView) rowView.findViewById(R.id.infotype);
        TextView EmailIdText = (TextView) rowView.findViewById(R.id.emailid);
        TextView PhoneNumText = (TextView) rowView.findViewById(R.id.phonenum);
        TextView AddressText = (TextView) rowView.findViewById(R.id.address);
        //Button btn = (Button) rowView.findViewById(R.id.button);

        NameText.setText(infoname[position]);
        TypeText.setText(infotype[position]);
        EmailIdText.setText(emailid[position]);
        PhoneNumText.setText(phnum[position]);
        AddressText.setText(address[position]);

        /*btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("Link : ", infolink[position]);

            }
        });*/
        return rowView;
    };
}