package com.example.mycityinfoapp;

public class NewInfoClass {
    private String infoId;
    private String infoName;
    private String infoType;
    private String emailId;
    private String phoneNum;
    private String address;

    public NewInfoClass() {
    }

    public NewInfoClass(String infoId, String infoName, String infoType, String emailId, String phoneNum, String address, String infoLink) {
        this.infoId = infoId;
        this.infoName = infoName;
        this.infoType = infoType;
        this.emailId = emailId;
        this.phoneNum = phoneNum;
        this.address = address;
        this.infoLink = infoLink;
    }

    public String getInfoId() {
        return infoId;
    }

    public void setInfoId(String infoId) {
        this.infoId = infoId;
    }

    public String getInfoName() {
        return infoName;
    }

    public void setInfoName(String infoName) {
        this.infoName = infoName;
    }

    public String getInfoType() {
        return infoType;
    }

    public void setInfoType(String infoType) {
        this.infoType = infoType;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public String getInfoLink() {
        return infoLink;
    }

    public void setInfoLink(String infoLink) {
        this.infoLink = infoLink;
    }

    private String infoLink;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }




}
