package com.example.mycityinfoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class UserMainPageActivity extends AppCompatActivity {

    private Button userviewprofilebtn, userallviewbtn, usersearchbtn, gobackbtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_main_page);

        userallviewbtn = (Button)findViewById(R.id.userviewallinfobtn);
        usersearchbtn = (Button) findViewById(R.id.usersearchbtn);
        userviewprofilebtn = (Button) findViewById(R.id.userviewprofilebtn);
        gobackbtn = (Button) findViewById(R.id.gobackbtn);

        userallviewbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), UserViewAllInfoActivity.class);
                startActivity(intent);
            }
        });

        userviewprofilebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), UserViewProfileActivity.class);
                startActivity(intent);
            }
        });

        usersearchbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), UserSearchActivity.class);
                startActivity(intent);
            }
        });

        gobackbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
    }
}